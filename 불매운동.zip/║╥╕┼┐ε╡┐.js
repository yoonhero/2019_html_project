function options(on){

var dom = document.getElementByID('myForm');

for(var index = 0; index < dom.colorButton.length; index++){
  if(dom.colorButton[index].checked){

  }
}


}
